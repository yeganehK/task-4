
function getDateDifference(date1,date2){
    var diffTime=Math.abs(date2 - date1);
    var diffDate=new Date(diffTime);
    var years=diffDate.getUTCFullYear() - 1970;
    var months=diffDate.getUTCMonth();
    var days=diffDate.getUTCDate() - 1;
   result.innerHTML=" years : " + years  + " months : " + months  + " days : " + days;
   return{years,months,days}

}



var result=document.getElementById('result');




function calc(){

    var birthday=document.getElementById('year').value;

    var date1=new Date(birthday);

    var date2=new Date();

   var dateDifference=getDateDifference(date1,date2);


}